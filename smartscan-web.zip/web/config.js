// Edit these 3 lines only. The anon/publishable key is safe in the frontend.
// NEVER put the secret / service_role key here.
window.CONFIG = {
  API_URL: "https://smartscan-api-yk3d.onrender.com",
  SUPABASE_URL: "PASTE_YOUR_SUPABASE_URL_HERE",
  SUPABASE_ANON_KEY: "PASTE_YOUR_PUBLISHABLE_OR_ANON_KEY_HERE",
};
